<footer>
        <div class="subnav navbar">
            <div class="container">
                <p class="text-info">&copy; <?php echo date('Y'); ?> <a href="http://www.hitec.org.cn">上海嘉国信息科技有限公司</a> 版权所有</p>
				<!--[if lt IE 8]>
                <code>注意事项：本系统采用HTML5技术，不支持IE6, IE7浏览器。请您使用<a href="http://www.microsoft.com/windows/Internet-explorer/">Internet Explorer 8</a>以上版本，或者<a href="http://www.mozilla.org">Firefox</a>, <a href="http://www.google.com/chrome">Google Chrome</a>浏览器访问。</code>
                <![endif]-->
            </div>
        </div>      
</footer>

