<?php
echo json_encode($list);






