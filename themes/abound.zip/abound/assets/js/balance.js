/**
 * Created by - on 23/02/14.
 */

$(document).ready(function () {

    $('#date').datepicker( {
        dateFormat: 'yymmdd'
    })
})